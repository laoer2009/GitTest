﻿using MPACore.PhoneBook.Configuration.Ui;

namespace MPACore.PhoneBook.Web.Views.Shared.Components.RightSideBar
{
    public class RightSideBarViewModel
    {
        public UiThemeInfo CurrentTheme { get; set; }
    }
}
