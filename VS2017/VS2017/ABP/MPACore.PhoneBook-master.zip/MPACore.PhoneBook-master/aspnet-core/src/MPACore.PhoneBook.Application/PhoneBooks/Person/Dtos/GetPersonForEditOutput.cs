﻿namespace MPACore.PhoneBook.PhoneBooks.Person.Dtos
{
    public class GetPersonForEditOutput
    {
        
        /// <summary>
        /// Person的编辑Dto
        /// </summary>
        public PersonEditDto Person { get; set; }


    }
}