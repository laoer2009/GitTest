﻿namespace MPACore.PhoneBook.PhoneBooks.Person.Dtos
{
    public class CreateOrUpdatePersonInput
    {
        

        public PersonEditDto PersonEditDto { get; set; }

    }
}