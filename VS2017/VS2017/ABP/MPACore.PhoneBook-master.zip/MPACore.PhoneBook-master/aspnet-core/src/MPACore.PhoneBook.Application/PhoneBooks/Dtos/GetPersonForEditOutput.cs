﻿using MPACore.PhoneBook.PhoneBooks.Person.Dtos;

namespace MPACore.PhoneBook.PhoneBooks.Dtos
{
    public class GetPersonForEditOutput
    {
        /// <summary>
        /// Person编辑状态的DTO
        /// </summary>
        public PersonEditDto Person { get; set; }

    }
}